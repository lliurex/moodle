[
    { "label": "first added", "enabled": false },
    { "label": "second added" },
    { "label": "third added", "enabled": false },
    { "label": "fourth added" }
]

NOTE:

To compile your plugin against the latest sources you should get the flowplayer
core sources from Github and compile the flowplayer.swc library from sources. This
module contains a 'recent' library version only.


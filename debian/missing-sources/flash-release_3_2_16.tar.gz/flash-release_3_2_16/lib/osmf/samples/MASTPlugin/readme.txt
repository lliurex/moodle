The MASTPlugin project is a plugin that adds support for MAST, and which integrates with the VAST plugin (which supports VAST 1.0).  It will eventually be deprecated in favor of MASTPluginNew.

The MASTPluginNew project is a newer implementation which integrates with the VASTNew library (which in turn provides support for VAST 1.0 and VAST 2.0).

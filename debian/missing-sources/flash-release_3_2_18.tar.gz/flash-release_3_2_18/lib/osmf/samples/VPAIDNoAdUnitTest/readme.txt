The purpose of this unit test is to ensure that the inclusion of the VAST and VPAID SWCs will not
cause errors with the OSMF when ads are not present.

Steps to test:
Publish VPAIDTestPlayer.fla
Launch VPAIDTestPlayer.html to test the video player

Expected results:
Content video will play.
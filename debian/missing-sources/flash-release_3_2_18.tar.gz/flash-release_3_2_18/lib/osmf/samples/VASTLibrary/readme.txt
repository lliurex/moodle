The VAST project provides support for VAST 1.0.  It will eventually be deprecated in favor of VASTNew.

The VASTNew project is a newer implementation which provides support for VAST 1.0 and VAST 2.0.

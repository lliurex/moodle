Version history:

3.2.15
------
- New build because of changes in shared code

3.2.14
------
- Added helper methods to hide / show the dock when autohide is enabled or not, issue #60

3.2.10
-------
- #605 Fixes for autoHide configuration

3.2.9
-----
- #583 Fixes for configuring the autoHide of the HD button

3.2.8
-----
- made it possible to configure the 'Embed code is copied to clipboard...' text, issue 262
Fixes:
- made it possible to disable embed and email
- updated Twitter sharing URL according to their new sharing API
- embed code now just uses the OBJECT tag, issue #301
- added new configuration option 'gap' to the dock. Defines the gap between buttons. Default is 5.
- the embed code now includes "wmode" with value "transparent". Issue #306
- #419 email link was disabled.
- #420 required to make the background assets for the share buttons the same as the included viral videos assets or else the alpha was not the same.
- #443 fixes for twitter button label for accessibility support.


3.2.1
-----
- dock enhancements

3.2.0
-----
- the first release
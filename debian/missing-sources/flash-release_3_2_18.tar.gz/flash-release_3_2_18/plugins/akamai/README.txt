Version history:

3.2.1
-----
Fixes:
- Now handles also other than .flv files

3.2.0
-----
Fixes:
- Fix for parsing a BOSS smil file (was firing error #1009 if protocol was not specified in the file)

3.1.3
-----
- compatible with the new ConnectionProvider and URLResolver API
- Added support for Akamai BOSS smil files (live streams etc)

3.1.2
------
- first public release

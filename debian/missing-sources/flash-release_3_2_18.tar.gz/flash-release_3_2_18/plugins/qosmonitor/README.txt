Version history:

3.2.8
-----

- #500 get the metrics from the bwcheck plugin, issue caused by adding the metrics to the clip properties model.
Version history:

3.2.13 (Nov 2013)
------
- #71 fixes for menu plugin to disable currently selected items to prevent toggling and over states.
  When other items are clicked and selected all other items will become enabled.

3.2.12
------
- #36 adjust the menu during fullscreen events as this is prevented once added to the stage.

3.2.11
------
- #7 check for stage availability before positioning the dock or position once stage is available when resetting menu items.

3.2.10
------
- new build because of changes in common libraries this plugin uses

3.2.9
-----
- #498 fixed to resize the label text to the menu item width.
- #563 added feature to dynamically select a menu item in a group. ability to get the menu button controller.
- #584 make the controls plugin name configurable.

3.2.8
-----
- First release!


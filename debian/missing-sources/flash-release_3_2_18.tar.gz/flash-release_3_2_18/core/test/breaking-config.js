{
	'clip': 
	{
		'scaling': 'fit',
		'url': 'http://www.blacktrash.org/media/manstalt.flv'
	},
	'plugins': 
	{
		'controls': 
		{
			'autoHide': 'false'
		}
			// scrubber is a well-known nickname for the timeline/playhead combination

			// you can also use the "all" flag to disable/enable all controls

			// you can also use the "all" flag to disable/enable all controls

			// you can also use the "all" flag to disable/enable all controls

	}

} 

Version history

3.0.3
-----
- controlbar movement is smoother, it is now updated in 100 millisecond intervals instead of the old 500 ms
- shows duration initially when { autoPlay: false, autoBuffering: true }

3.0.2
-----
- time display
- mute / unmute

3.0.1
-----
- plugin chaining was forgotten
- made it work with playlists

public beta2
------------
- safari playhead positioned correclty
- play button goes to paused state upon onStart

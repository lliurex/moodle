Version history

3.2.8
-----
- first release
- Fix for #322, template is not selectable until later on.
- Added seperator option back in.

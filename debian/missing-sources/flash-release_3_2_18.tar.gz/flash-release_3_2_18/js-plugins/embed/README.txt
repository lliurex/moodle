Version history

3.0.2
-----
- index can be given as argument
